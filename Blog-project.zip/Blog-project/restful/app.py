from flask import Flask,request
from flask_restful import Resource,Api,reqparse
import json
import jwt
from datetime import datetime as dt
from datetime import timedelta


app = Flask(__name__)
api = Api(app)
app.config['SECRET_KEY']='qwertyuiop'
blogs = [
    {
        'title':'blog post1',
        'author':'user1',
        'content':'qwsdfg,ojvc',
        'date_created': 'nov 29',
        'date_modified': 'dec 2',
        'cover_img': '/static/img/blog1',
        'id' : '1'
    }
]


class blog(Resource):
    def get(self,title):
        return next(filter(lambda x : x['title']==title,blogs),None)
    def post(self,title):
        token = request.args.get('token')
        if token:
            try:
                data = jwt.decode(token,app.config['SECRET_KEY'])
            except:
                return {'token invalid'}
            if next(filter(lambda x : x['title']==title,blogs),None):
                return {'message':'Blog post with title : {} already exists'.format(title),'error code':400}
            else:
                data = request.get_json()
                blogs.append(data)
                return 200
        else:
            return {'message': 'Token missing'}
    def put(self,title):
        token = request.args.get('token')
        if token:
            try:
               data = jwt.decode(token,app.config['SECRET_KEY'])
            except:
                return {'token invalid'}
            if next(filter(lambda x : x['title']==title,blogs),None):
                newblog = request.get_json()
                return newblog
            else:
                data = request.get_json()
                blogs.append(data)
                return 200
        else:
            return {'message': 'Token missing'}

@app.route('/login')
def login():
    credentials = request.authorization
    if credentials:
        if credentials.username=='abc' and credentials.password == 'qwerty':
            token = jwt.encode({'username': credentials.username,'exp':dt.utcnow()+timedelta(minutes=1)},app.config['SECRET_KEY'])
            return token
        else:
            return {'message':'Wrong credentials'}
    else:
        return {'message':'Authorization needed'}

api.add_resource(blog,'/blog/<string:title>')

app.run()