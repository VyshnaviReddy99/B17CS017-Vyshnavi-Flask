from flask import Flask, request, jsonify
from flask_restful import Resource,Api,reqparse
import datetime as dt
import json
from jwt import encode,decode
from functools import wraps



app = Flask(__name__)
api = Api(app)

app.config['SECRET_KEY'] = 'qwertyuiop'

def token_required(fun):
    @wraps(fun)
    def decorated(*args,**kwargs):
        token = request.args.get('token')
        if token:
            try:
                decode(token,app.config['SECRET_KEY'])
            except:
                return jsonify({'message':'Token Invalid'})
            return fun(*args,**kwargs)
        else:
            return jsonify({'message': 'Token is missing'})
    return decorated
        
blogs=[]
class blog(Resource):
    def get(self,name):
        return next(filter(lambda x: x['name']==name,blogs),None)
    @token_required 
    def post(self,name):
        new_blog =  request.get_json()
        if next(filter(lambda x: x['name']==name,blogs),None):
            return {'message':'A blog with same title already exists'},400
        else:
            new_blog['time'] = dt.datetime.utcnow().strftime('%Y-%m-%d %H:%M')
            blogs.append(new_blog)
            return 200
    @token_required        
    def put(self,name):
        new_blog =  request.get_json()
        old_blog = next(filter(lambda x: x['name']==name,blogs),None)
        if old_blog:
            return new_blog
        else:
            new_blog['time'] = dt.datetime.utcnow().strftime('%Y-%m-%d %H:%M')
            blogs.append(new_blog)
            return 200
    @token_required 
    def delete(self,name):
        global blogs
        blogs = list(filter(lambda x: x['name'] != name, None))
        return {'message' : 'Blogs deleted'}


@app.route('/')
def home():
    return "<h1>HI</h1>"

@app.route('/login')
def login():
    cred = request.authorization
    if cred.username == 'abc' and cred.password == 'def':
        token = encode({'user':cred.username,'exp': dt.datetime.utcnow()+dt.timedelta(minutes=2)},app.config['SECRET_KEY'])
        return token
    else:
        return jsonify({'message':'Wrong credentials'})
api.add_resource(blog,'/blog/<string:name>')

app.run()